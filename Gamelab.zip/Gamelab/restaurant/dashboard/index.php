<?php include("../layout/header.php") ?>


     <div style="text-align: center;">
     <h2>Selamat datang <?= $_SESSION['name']; ?> di Restaurant</h2>
     
     <?php include("../layout/footer.php");