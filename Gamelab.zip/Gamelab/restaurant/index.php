<?php

header("Location: dashboard");
?>